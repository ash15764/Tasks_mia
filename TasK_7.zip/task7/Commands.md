﻿***~ Cd Command :-***

**Definition :-** this command is generally used for changing the global directory of the system ->

![](Aspose.Words.c91c5342-b385-4501-8fd1-c159e8931bdd.001.png)![](Aspose.Words.c91c5342-b385-4501-8fd1-c159e8931bdd.002.png)![](Aspose.Words.c91c5342-b385-4501-8fd1-c159e8931bdd.003.png)

![](Aspose.Words.c91c5342-b385-4501-8fd1-c159e8931bdd.004.png)

![](Aspose.Words.c91c5342-b385-4501-8fd1-c159e8931bdd.005.png)

‘~’ -> a general directory that points to nothing.

***~ ls Command :-***

**Definition :-** this command is used for showing all the folders and the files in a specific directory ->

![](Aspose.Words.c91c5342-b385-4501-8fd1-c159e8931bdd.006.png)

![](Aspose.Words.c91c5342-b385-4501-8fd1-c159e8931bdd.007.png)

***~ pwd Command :-***

**Definition :-** this command is used for printing the directory on the screen ->

![](Aspose.Words.c91c5342-b385-4501-8fd1-c159e8931bdd.008.png)

***~ mkdir Command :-***

**Definition :-**  this command is used for creating an empty folder in a specific directory ->

![](Aspose.Words.c91c5342-b385-4501-8fd1-c159e8931bdd.009.png)![](Aspose.Words.c91c5342-b385-4501-8fd1-c159e8931bdd.010.png)

![](Aspose.Words.c91c5342-b385-4501-8fd1-c159e8931bdd.011.png)![](Aspose.Words.c91c5342-b385-4501-8fd1-c159e8931bdd.012.png)

***~ rm Command :-***

**Definition :-**  this command is used for removing a file from a directory ->

![](Aspose.Words.c91c5342-b385-4501-8fd1-c159e8931bdd.013.png)

***~ mv Command :-***

**Definition :-**  this command used to move a file from its current location to a new location ->

![](Aspose.Words.c91c5342-b385-4501-8fd1-c159e8931bdd.014.png)

***~ cat Command :-***

**Definition :-**  it globally work word around modifying a file, for Example ->

“-n” à opening a file.

“>” à creating a file and write its data.

![](Aspose.Words.c91c5342-b385-4501-8fd1-c159e8931bdd.015.png)

***~ nano Command :-***

**Definition :-** Show a data inside a readable file in a new window ->

![](Aspose.Words.c91c5342-b385-4501-8fd1-c159e8931bdd.016.png)

![](Aspose.Words.c91c5342-b385-4501-8fd1-c159e8931bdd.017.png)

![](Aspose.Words.c91c5342-b385-4501-8fd1-c159e8931bdd.018.png)

![](Aspose.Words.c91c5342-b385-4501-8fd1-c159e8931bdd.019.png)


