#include <iostream>
#include <algorithm>
#include <vector>
using namespace std;

int main()
{
    int sz;
    cin>>sz;
    vector<int> energy(sz);
    for(int i = 0 ; i < sz ; ++i){
            cin>>energy[i];
    }
    vector<int> val(1);
    cin>>val[0];
    vector<int>::iterator index;
    index = search(energy.begin(),energy.end(),val.begin(),val.end());
    if(index != energy.end()){
        cout<<index-energy.begin()<<endl;
    }
    else{
        cout<<-1<<endl;
    }
    return 0;
}
