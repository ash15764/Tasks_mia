#include <iostream>

using namespace std;

int main()
{
    int l;
    cin>>l;
    int max = 0;
    int heights[l];
    for(int i = 0 ; i < l ; ++i){
        cin>>heights[i];
        if(heights[i] > max){
            max = heights[i];
        }
    }
    cout<<max<<endl;
    return 0;
}
