#include <iostream>

using namespace std;

int main()
{
    int d1,d2;
    cin>>d1>>d2;
    int jl[d1][d2];
    int Vi[d1][d2];
    for(int i = 0 ; i < d1 ; ++i){
        for(int j = 0 ; j < d2 ; ++j){
            cin>>jl[i][j];
        }
    }
    for(int i = 0 ; i < d1 ; ++i){
        for(int j = 0 ; j < d2 ; ++j){
            cin>>Vi[i][j];
        }
    }
    int winj = 0;
    int winv = 0;
    int tie = 0;
    for(int i = 0 ; i < d1 ; ++i){
        for(int j = 0 ; j < d2 ; ++j){
            if(jl[i][j] > Vi[i][j]){
              ++winj;
            }
            else if(jl[i][j] < Vi[i][j]){
                ++winv;
            }
            else{
                ++tie;
            }
        }
    }
    if(winj > winv && winj >= tie){
        cout<<"Justice League"<<endl;
    }
    else if (winv > winj && winv >= tie){
        cout<<"Villains"<<endl;
    }
    else if((tie > winj && tie > winv) || winj == winv){
        cout<<"Tie"<<endl;
    }
    return 0;
}
