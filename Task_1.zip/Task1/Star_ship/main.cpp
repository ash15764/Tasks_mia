#include <iostream>

using namespace std;

int main()
{
    int lim;
    cin>>lim;
    for(int i = 1; i <= lim ; ++i){
        for(int j = 0 ; j < i ; ++j){
            cout<<'*';
        }
        cout<<endl;
    }
    return 0;
}
